/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

template<class T>
T add(T x, T y){
   return (x+y); 
}
template<class T>
T add(T x, T y, T z){
   return (x+y+z); 
}

template<class T, class U>
T add(T x, U y){
   return (x+y); 
}

template <class H>
        
H add(H  *arr, int len)
{
     H sum = 0;
    for (int i = 0; i < len; i++) {

       
        sum = sum + arr[i];
       
        
    }
 
    return sum;
}

int main()
{
    //hybrid 
    // cout<<add<int,double>(3,7.77)<<endl;
    // cout<<add<float,float>(3.3,7.5)<<endl;
    // cout<<add<double,float>(3.55,7.66)<<endl;
    
    //simple
    cout<<endl;
    cout<<add(5,7)<<endl; //interger addition.
    // cout<<add(5,7.7)<<endl;
    cout<<add(5.5, 6.6)<<endl; //float addition
    
    cout<<add(5,6,7)<<endl;
    cout<<add(5.5,6.6,7.7)<<endl;
    
    
    cout<<endl;
     int numArr[] = { 10, 20, 30, 40, 50 };
     cout<<add(numArr,5)<<endl;
     
     double arr1[] = {1.1,2.2,3.3};
     cout<<add(arr1, 3)<<endl;
    return 0;
    
    
    
}




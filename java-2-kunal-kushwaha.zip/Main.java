/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//WE KNOW THAT SOMETHING IS NOT STATIC BELONGS TO AN OBJECT.
//A STATIC METHOD CAN ONLY ACCESS A STATIC DATA
//A NON STATIC MEMBER BELONGS AN INSTANT.
//IF IT IS NON STATIC THEN OBJECT WILL BE REQUIRED IN STATIC CONTEXT.
//EVERYTING YOU WTITE IS GOING TO GET CALLED BY STAITIC METHOD DIRECTLY OR INDIRECTLY.
//A STATIC METHOD CAN CALL ONLY A STATIC METHOD. OTHERWISE YOU WILL NEED A REFERENCE(OBJECT).


class StaticBLock {
    static int a = 4;
    static int b;
    
    //will only run once, when the first obj is created. i.e.
    //When the class is loaded for the the first time as you can say im in static bloc only got printed once.
    static {
        System.out.println("I am in static block");
        b = a * 5;
        
    }
}

// class InnerClasses {
    
//     //we create inner classes as static because they become independent of outside classes objects.
    
//     //we make them independed of objects of outside class.
//     static class Test {
//         String name;
//         public Test(String name){
//             this.name = name;
//         }
//     }
    
//     //STATIC MEANS IT CAN HAVE INSTANCES WITH MAIN OR ANYOTHER CLASS BUT JUST IT CANNOT HAVE INSATANCE OF ITS OUTISIDE CLASS.
// }
public class Main //outside classes cannot be static.we need this not to be static so its object can be created to usea non satic methods.
{
	public static void main(String[] args) {
	
	Human Kunal = new Human(32, "Kunal", 100000, false);	
	Human Kshitij = new Human(33, "Kshitij", 10000, false);	
	
	System.out.println(Human.population);
	System.out.println(Human.population);
	
	greeting();
	
	Main funn = new Main(); //object is created to accesss non static here.
	funn.fun2();
	funn.greet();
	fun();
	
	
	StaticBLock obj = new StaticBLock();
	System.out.println(StaticBLock.a + " " + StaticBLock.b);
	StaticBLock.b += 3;
	System.out.println(StaticBLock.a + " " + StaticBLock.b);
	StaticBLock obj2 = new StaticBLock();
	System.out.println(StaticBLock.a + " " + StaticBLock.b);
	
	Singleton obj = Singleton.getinstance();
// 	Test a = new Test("Kshitij");
// 	Test b = new Test("don");
	
// 	System.out.println(a.name);
// 	System.out.println(b.name);

    
    
	}
	
	
	static void greeting(){
	    System.out.println("hello world");
	}
	
	void greet(){
	    System.out.println("hello kshitij");
	}
	
	static void fun(){
	    System.out.println("im static, i dont neeed an object to run");
	    //you cannot access non static stuff without referencing thier instances ONLY
	    //A STATIC CONTEXT
	    
	    //HERE WE ARE REFERENCING IT. AS GREET DEPENDS ON AN OBJECT AS IT IS NOT STATIC.
	    //greet TERA OBJECT KAHA HE???
	    Main obj = new Main();
	    obj.greet();
	}
	
	void fun2(){
	    greet();
	    
	    //OBJECT FOR FUN2 WILL BE CREATED IN MAIN SO WE DONT NEED TO WORRY HERE.
	    //AS GREETING METHOD WILL BE PART OF THE FUN2
	}
	
}

     class Human {
    int age;
    int salary;
    String name;
    boolean married;
    static long population;
    
    Human(int age, String name, int salary, boolean married){
        this.age = age;
        this.name = name;
        this.salary = salary;
        this.married = married;
        
        Human.population += 1;    //STATIC DATA VARIABLES ARE THOSE WHO ARE COMMON FOR EACH OBJECT. THEY HAVE SAME VALUE FOR EACH OBJECT.
        //STATIC IS NOT ACCESSED USING THIS. BECAUSE IT IS NOT OBJECT DEPENDENT.
        //STATIC IS OBJECT INDEPENDENT;
        //If no object is created you can still use it.
    }
    static void message(){
        System.out.println("hey hey");
        // system.out.println(this.age); you cannot use this keyword in static methods.
        //this actually represents an object.
    }
}




	//for evry single student;
	class Student {
	    int rno;
	    String name;
	    float marks;
		//iski default values 0 null wagera hoti.
		//pehle compiler object me values dhundta agar waha nai mili toh woh
		//class template me jo values he wo assign karta
		//by defined constructor has these values
		
		void greeting(){
		    System.out.println("hello my name is " + this.name);//this.name is not needed.cuz constructor has a value.
		}
		void display(){
		System.out.println("THIS INFO IS FOR: " + this.name);
		System.out.println(this.rno);
		System.out.println(this.name);
		System.out.println(this.marks);
		}
	    Student(){
	       // this.rno = 13; //kunal. kshitij. ki jagah hum this use karte
	       // this.name = "kunal";
	       // this.marks = 90.0f;
	       
	       //this is how you call another constructor from a constructor.
	       //iske neeche wale construcotr ko use karta he ye through this.
	       this ( 0, "default person",  100.0f);
	    }
	    
	    Student(int rno, String name , float marks){
	        this.rno = rno;
	        this.name = name;
	        this.marks = marks;//use this. if the arguments in the construcots are data members
	    }
	    
	    //above thing is constructor overloading.-polymorphism
	    void changeName(String newName){
	        this.name = newName;
	    }
	    
	    Student (Student otherObj){
	        this.name = otherObj.name;
	        this.rno = otherObj.rno;
	        this.marks = otherObj.marks;//for copying values of another object for thius  object
	    }
	    

	}
	
	class A {
	    final int num = 10;
	    String name;
	    
	    public A(String name) {
	        this.name = name;
	    }
	    
	    	@Override
	protected void finalize() throws Throwable {
        System.out.println("object is destroyed"); //deconstrucor like concept
	}
	}
	
	
	//SINGLETON class- iska ek hi object banega sirf
	public class Singleton{
	    private Singleton(){ //it will be only used in this class. cant be used anywherre else.
	        
	    }
	    
	    private static Singleton instance;
	    
	    public static Singleton getinstance(){
	        //check if only one object
	        
	        if(instance == null){
	            instance == new Singleton();
	        }
	        return instance;
	    }
	}
	


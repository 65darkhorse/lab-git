/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

template <class T>
class test {
    T a,b;
    
    public:
    
    T add();
    //     T add(){
    //     return (a + b);
    // }
    
    test (T x, T y){
        a = x;
        b = y;
    }
    test (){
        a = 0;
        b = 0;
    }
};

template <class T>
T test<T> :: add(){
    return a + b;
}
int main()
{
    
    test <int> obj1(1,2);
    cout<<obj1.add()<<endl;
    test<float> obj2(1.1,2.2);
    cout<<obj2.add()<<endl;
    return 0;
}
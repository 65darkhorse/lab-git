/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class calendar {
  public:
    calendar() {day = 0; month = 0; year = 0;}
    calendar(int d, int m, int y) {day = d; month = m; year = y;}
  
    int getDay() const {return day;}
    int getMonth() const {return month;}
    int getYear() const {return year;}
  
    void setDay(int d) {day = d;}
    void setMonth(int m) {month = m;}
    void setYear(int y) {year = y;}
  
    void output() {
      cout << "DAY: " << day << "\nMONTH: " << month << "\nYEAR: " << year << endl;
    }
  
    friend bool equal(const calendar x1, const calendar x2);

  private:
    int day, month, year;
};

bool operator ==(const calendar x1, const calendar x2) {
    return (x1.getDay() == x2.getDay()) && (x1.getYear() == x2.getYear()) && (x1.getMonth() == x2.getMonth());
}

int main() {
    calendar o1(3, 11, 2021), o2(4, 11, 2021);

    cout << (o1 == o2) << endl; //we created our own class so we have to give our own defination

    return 0;
}

